Unzip both packs and follow READMEs.
